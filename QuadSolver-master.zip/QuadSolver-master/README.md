# QuadSolver
A quadratic formula solver

Should work with:
gcc main.c ./qsolve/qsolve.c ./IO/Input.c ./Log/OpenLog.c ./Log/CloseLog.c ./Log/WriteLog.c -o demo -lm -Wall
