The qsolve src code. Contains the .c and .h file for qsolve.
