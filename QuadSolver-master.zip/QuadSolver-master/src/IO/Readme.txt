This directory holds code for the input & output functions
Makefile: type 'make IO' to compile the code for just the Input & Output files, or 'make Driver' to test with CUnit
