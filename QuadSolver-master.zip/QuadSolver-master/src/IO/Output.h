void Output(char* output);
