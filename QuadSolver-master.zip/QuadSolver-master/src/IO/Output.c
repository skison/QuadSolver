/*
Input: a string containing the final answer 

This function simply outputs this string to stdout
*/
#include <stdio.h>

void Output(char* output)
{
	fprintf( stdout, "%s", output);
}
