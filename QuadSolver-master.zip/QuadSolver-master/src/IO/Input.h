int Input(char* input);
