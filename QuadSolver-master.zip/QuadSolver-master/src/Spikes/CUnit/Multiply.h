int Multiply(int first, int second);
