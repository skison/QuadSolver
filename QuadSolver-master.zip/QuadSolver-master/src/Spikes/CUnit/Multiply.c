//Just multiply 2 ints together
int Multiply(int first, int second)
{
	int mult = first * second;
	return mult;
}