This directory holds test code for CUnit - unit testing. Simply run the Makefile ('make Driver') to compile it, and ./Driver to run.
To install CUnit, type: sudo apt-get install libcunit1 libcunit1-doc libcunit1-dev
NOTE- the unit test intentionally includes tests that WILL fail.
