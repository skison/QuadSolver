This directory holds source code for project spikes
