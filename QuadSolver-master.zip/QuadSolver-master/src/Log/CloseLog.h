int CloseLog(FILE* fp);
