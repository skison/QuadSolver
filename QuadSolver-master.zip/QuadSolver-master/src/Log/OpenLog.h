FILE* OpenLog(char* filepath, int mode);
