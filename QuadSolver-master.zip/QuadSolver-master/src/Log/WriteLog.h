int WriteLog(FILE* fp, char* outputText);
