This directory holds code for the Log functions, specifically OpenLog, WriteLog, and CloseLog.

To compile, just type 'make Log' or 'make Driver' for CUnit Testing
