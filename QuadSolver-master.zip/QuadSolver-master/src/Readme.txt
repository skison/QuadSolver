This is the top-level directory for all source code in the QuadSolver project


In order to run the main.c, run "make"
